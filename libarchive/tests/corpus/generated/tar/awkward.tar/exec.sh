Hello, libarchive-rs!
